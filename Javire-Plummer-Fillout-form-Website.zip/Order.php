<!-- Javire Plummer -->
<?php
$isFormValid = true;
$displayForm = true;

if(isset($_POST['submit']))
  ?>
  <!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta charset="UTF-8">
<img src="https://storage.googleapis.com/pod_public/1300/180356.jpg" alt="basketball" width="180" height="180">"
<div id="wrapper">  
<title>Assignment #1: "Order Form"</title>
  <link rel="stylesheet" href="order.css">
    <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">

</head>
<body><kbd>

  <style>
    body{
      background-color: white;
      h1 {color: black;}
    }
  </style>


  <link rel="Stylesheet" href="styles.css">
  <h1> ITEC 464: Assignment #1 </h1>

  <fieldset><legend> Billing Address </legend>
     
    <legend> Input your first name here </legend>
    <input type= "text" name= "fname" id= "fname" maxlength = "10" />
    <legend> Input your last name here </legend>
    <input type= "text" name= "lname" id="lname" maxlength = "15" />

    <legend> Input your home address </legend>
    <input type= "text" name= "address" id="address" maxlength = "20" />

    <legend> Input your city here </legend>
    <input type= "text" name= "city" id="city" maxlength = "20" />

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST"){
      $city = $_POST['city'];
      $address = $_POST['address'];
      $fname = $_POST['fname'];
      $lname = $_POST['lname'];
      $check = false;
      

      if($_SERVER["REQUEST_METHOD"] == "POST"){
        isset($_POST['check']);
        $fName = $_POST['fname'];
        $lName = $_POST['lname'];
        $hmAddress = $_POST['address'];
        $homeCity = $_POST['city'];
      }

      if(isset($_POST['submit'])) {
        if(empty($city) && empty($address) && empty($fName) && empty($lName)) {
          echo "<p> You must enter a value in all the required fields </p>";
        }
        }
      }
   ?>

   </fieldset>

    <fieldset><legend>Delivery Address </legend>    
       <legend> Same as billing </legend>
        <input type= "checkbox" name= "check" id = "check"/> 
        <legend> Input your first name here </legend>
        <input type= "text" name= "fName" id= "fName" maxlength = "10" />

        <legend> Input your last name here </legend>
        <input type= "text" name= "lName" id="lName" maxlength= "15" />

        <legend> Input your home address </legend>
        <input type= "text" name= "hmAddress" id="hmAddress" maxlength= "20" />

        <legend> Input your city here </legend>
        <input type= "text" name= "homeCity" id="homeCity" maxlength= "20" / >

      <?php
      if (isset($_POST['check'])) {
        $check = true;
        $fName = $fname;
        $lName = $lname;
        $hmAddress = $address;
        $homeCity = $city;
      } else {
        $check = false;
        echo "<p> Please input your delivery address </p>";
      }
      ?>
      </fieldset>
        <fieldset>

      
    </h3>
    </fieldset>

  <label for= "States">Select a State</label>

  <select name="States" id="states">
    <option value=" "> </option>
    <option value="AL">Alabama</option>
    <option value="AK">Alaska</option>
    <option value="AZ">Arizona</option>
    <option value="AR">Arkansas</option>
    <option value="CA">Californa</option>
    <option value="CO">Colorado</option>
    <option value="CT">Connecticut</option>
    <option value="DE">Delaware</option>
    <option value="FL">Florida</option>
    <option value="GA">Georgia</option>
    <option value="Hi">Hawaii</option>
    <option value="ID">Idaho</option>
    <option value="IL">Illnois</option>
    <option value="IN">Indiana</option>
    <option value="IA">Iowa</option>
    <option value="KS">Kansas</option>
    <option value="KY">Kentucky</option>
    <option value="LA">Louisiana</option>
    <option value="ME">Maine</option>
    <option value="MD">Maryland</option>
    <option value="MA">Massachusetts</option>
    <option value="MI">Michigan</option>
    <option value="MN">Minnesota</option>
    <option value="MS">Mississippi</option>
    <option value="MO">Missouri</option>
    <option value="MT">Montana</option>
    <option value="NE">Nebraska</option>
    <option value="NV">Nevada</option>
    <option value="NH">New Hampshire</option>
    <option value="MT">Montana</option>
    <option value="NJ">New Jersey</option>
    <option value="NM">New Mexico</option>
    <option value="NY">New York</option>
    <option value="NC">North Carolina</option>
    <option value="ND">North Dakota</option>
    <option value="OH">Ohio</option>
    <option value="OK">Oklahoma</option>
    <option value="OR">Oregon</option>
    <option value="PA">Pennsylvania</option>
    <option value="RI">Rhode Island</option>
    <option value="SC">South Carolina</option>
    <option value="SD">South Dakota</option>
    <option value="TN">Tennessee</option>
    <option value="TX">Texas</option>
    <option value="UT">Utah</option>
    <option value="VT">Vermont</option>
    <option value="VA">Virginia</option>
    <option value="WA">Washington</option>
    <option value="WV">West Virginia</option>
    <option value="WI">Wisconsin</option>
    <option value="WY">Wyoming</option>
    </select>

    <?php
    if($_SERVER["REQUEST_METHOD"] == "POST") {
      $states = $_POST["States"];

      if(isset($_POST['submit'])) {
        if($states == " ") {
          echo "<p> ERROR: You must select a state </p>";
        }
      }
    }
    ?>

</fieldset>

  
  <h2> Payment </h2>
  <fieldset>
    <legend> Select a payment method </legend>
    <input type="radio" id="visa" name="visa" value="HTML">
    <label for="visa">Visa</label><br>

    <input type="radio" id="discover" name="discover" value="HTML">
    <label for="discover">Discover</label><br>

    <input type="radio" id="mastercard" name="masterCard" value="HTML">
    <label for="mastercard">MasterCard</label><br>

    <input type="radio" id="americanexpress" name="americanexpress" value="HTML">
    <label for="american express">American Express</label><br>

    <fieldset>
    <legend> Input your card number</legend>
    <input type= "text" name= "cardnum" maxlength= "16"/>
      
    <label for= "expiration">Select your card expiration month </label>

    <select name="expiration" id="expiration">
      <option value="0"> </option>
      <option value="1">01</option>
      <option value="2">02</option>
      <option value="3">03</option>
      <option value="4">04</option>
      <option value="5">05</option>
      <option value="6">06</option>
      <option value="7">07</option>
      <option value="8">08</option>
      <option value="9">09</option>
      <option value="10">10</option>
      <option value="11">11</option>
      <option value="12">12</option>
      </select>

      <label for ="Year"> Select your card expiration year </label>

      <select name= "year" id="year">
        <option value="0"> </option>
        <option value="1">2024</option>
        <option value="2">2025</option>
        <option value="3">2026</option>
        <option value="4">2027</option>
        <option value="5">2028</option>
        <option value="6">2029</option>
      </select>

      <legend> Input your CVV </legend>
      <input type= "text" name= "cvv" id="cvv" minlength="3" maxlength="3" />

      <?php
      if($_SERVER["REQUEST_METHOD"] == "POST") {
        $cardNum = $_POST["cardnum"];
        $year = $_POST["year"];
        $cvv = $_POST["cvv"];
        $expiration = $_POST["expiration"];

        if(isset($_POST['submit'])) {
          if(empty($cardNum) && empty($expiration) && empty($year) && empty($cvv) && empty($states)) {
            echo "<p> ERROR: You must enter a value in all the required fields </p>";
            }
        if(isset($_POST['submit'])) {
          if(strlen($cardNum) < 16 || strlen($cardNum) > 16){
            echo "<p> ERROR: Your card number must be 16 digits long </p>";
          }
          else if(isset($_POST['submit'])) {
            if(empty($expiration)) {
              echo "ERROR: You must select an expiration month";
            }
          }
        }
          }
        }
      ?>

  </fieldset>

  <h2> Create Account </h2>
  <fieldset>
    <legend> Create your username (Min 5 characters) </legend>
    <input type= "text" name= "username" />
    <?php
    if($_SERVER["REQUEST_METHOD"] == "POST") {
      $username = $_POST["username"];
      // Good, your form is valid
      if (strlen($username) < 5) {
        echo "<p> Username has to be at least 5 characters long </p>"; } else {
          echo "<p> Your username is valid! </p>";
        }
      }
    ?>
    

    <legend> Create your password (min 8 characters) </legend>
    <input type= "password" name= "password" id="password" />

    <legend> Enter your password again (min 8 characters) </legend>
    <input type= "password" name= "conPassword" id="conPassword" />
      <?php
      if($_SERVER["REQUEST_METHOD"] == "POST") {
        $password = $_POST["password"];
        $conPassword = $_POST["conPassword"];

         if(isset($_POST['submit'])) {
        if ($password !== $conPassword || $password == "" && $conPassword == "" )
             echo "<p> Please verify that your passwords match </p>";
        } 
      }
    ?> 
        </fieldset>
        <?php
        echo '<form method="post" action="results.php">';
        if($_SERVER["REQUEST_METHOD"] == "GET") {
        $username = $_GET["username"] ?? "";
        $password = $_GET["password"] ?? "";
        $conPassword = $_GET["conPassword"] ?? "";
        $states = $_GET["States"] ?? "";
        $fName = $_GET["fName"] ?? "";
        $lName = $_GET["lName"] ?? "";
        $hmAddress = $_GET["hmAddress"] ?? "";
        $address = $_GET["address"] ?? "";
        $homeCity = $_GET["homeCity"] ?? "";
        $city = $_GET["city"] ?? "";
        $cardNum = $_GET["cardnum"] ?? "";
        $year = $_GET["year"] ?? "";
        $cvv = $_GET["cvv"] ?? "";
        $fname = $_GET["fname"] ?? "";
        $lname = $_GET["lname"] ?? "";
        }
        if ($fName && $lName && $address && $city && $states && $cardNum && $year && $cvv && $username && $password && $conPassword == true) {
        echo "<h7> Good Job! Your order has been place successfully!! </h7>";
        echo "<p><strong> First Name: </strong> $fName </p>";
        echo "<p><strong> Last Name: </strong> $lName </p>";
        echo "<p><strong> Billing Address: </strong> $address </p>";
        echo "<p><strong> Billing City: </strong> $city </p>";
        echo "<p><strong> Card: </strong> $cardNum </p>";
        echo "<p><strong> Year: </strong> $year </p>";
        echo "<p><strong> CVV: </strong> $cvv </p>";
        echo "<p><strong> Username: </strong> $username </p>";
        echo "<p><strong> Password: </strong> $password </p>";
        echo "<p><strong> Confirm Password: </strong> $conPassword </p>";
        echo "<p><strong> Delivery First and Last Name: </strong> $fName $lName </p>";
        echo "<p><strong> Delivery Address: </strong> $hmAddress </p>";
          echo "<p><strong> Delivery City: </strong> $homeCity </p>";
           echo "<p><strong> State: </strong> $states </p>";
        }
        ?>
        <input type="submit" name="submit" value="Submit" />
        </form>
  <footer>
    <p>&#169; Copyright 2024 [Javire Plummer]</p>
  </footer>

<!--Javire Plummer-->
        
</body>
</kbd>
</html>